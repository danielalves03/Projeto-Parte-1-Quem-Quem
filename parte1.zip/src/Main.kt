var personagens : Array<Array<String>> = emptyArray()
private const val MENSAGEM_PERSONAGENS_LIDOS_COM_SUCESSO = "Personagens lidas com sucesso."
const val MASCULINO = "masculino"
const val FEMININO ="feminino"
const val LISO = "liso"
const val ONDULADO = "ondulado"
const val CARECA = "careca"
const val CASTANHO = "castanho"
const val CASTANHOS = "castanhos"
const val AZUL = "azuis"
const val VERDE = "verdes"
const val INDT = "-"
var jogoAtivo = false
var indicePersonagemEscolhido = -1

fun obterMenu(): String {
    return("\n##### QUEM E QUEM!!! #####\n\n") +
            ("Escolha uma opcao:\n") +
            ("1 - Jogar\n") +
            ("2 - Ler personagens\n") +
            ("0 - Sair\n")

}

fun obterMenuJogo(): String {
    return "\nEscolha uma opcao:\n" +
            "perguntar   - para perguntar retirando personagens do jogo\n" +
            "personagens - para consultar as personagens em jogo\n" +
            "sair        - para sair do jogo\n"

}

fun lerPersonagens(): Boolean {
    personagens = arrayOf(
        arrayOf("# Nome","Genero","Cabelo","Cor","Olhos"),
        arrayOf("0 Joao",MASCULINO,LISO,CASTANHO,CASTANHOS),
        arrayOf("1 Mario",MASCULINO,CARECA,INDT,AZUL),
        arrayOf("2 Sofia",FEMININO,ONDULADO,CASTANHO,CASTANHOS),
        arrayOf("3 Joana",FEMININO,LISO,CASTANHO,VERDE)
    )

    return true
}
fun mostrarPersonagens(): String {
    if (personagens.size == 2) {
        val ultimoPersonagem = personagens[1]
        println("Parabens! A personagem e o/a ${ultimoPersonagem[0]}")
        jogoAtivo = false
        indicePersonagemEscolhido = -1
        return ""
    }
    var saida = "Personagens em jogo:\n"

    val larguraMaxima = IntArray(personagens[0].size) { 0 }
    for (linha in personagens) {
        for (i in linha.indices) {
            if (linha[i].length > larguraMaxima[i]) {
                larguraMaxima[i] = linha[i].length
            }
        }
    }

    for (i in personagens[0].indices) {
        val coluna = personagens[0][i]
        val espacosAdicionar = larguraMaxima[i] - coluna.length
        saida += coluna
        for (index in 0 until espacosAdicionar) {
            saida += " "
        }
        if (i < personagens[0].size - 1) {
            saida += " | "
        }
    }
    saida += "\n"

    for (i in 1 until personagens.size) {
        for (j in 0 until personagens[0].size) {
            val coluna = personagens[i][j]
            val espacosAdicionar = larguraMaxima[j] - coluna.length
            saida += coluna
            for (index in 0 until espacosAdicionar) {
                saida += " "
            }
            if (j < personagens[0].size - 1) {
                saida += " | "
            }
        }
        saida += "\n"
    }
    return saida
}
fun gerarPersonagem(): Int {
    return (1 until personagens.size).random()
}
fun perguntar(pergunta: String, indicePersonagemEscolhido: Int): Int {
    val perguntaPartes = pergunta.split(" ")

    if (perguntaPartes.size != 2) {
        return -1
    }

    val (atributo, valor) = perguntaPartes
    val indiceAtributo = when (atributo) {
        "genero" -> 1
        "cor" -> 3

        "cabelo" -> 2
        "olhos" -> 4
        else -> return -1
    }

    var retiradas = 0
    var iii = 1
    while (iii < personagens.size) {
        val personagemAtual = personagens[iii]
        if (personagemAtual[indiceAtributo] != valor) {
            retirarDeJogo(iii)
            retiradas++
        } else {
            iii++
        }
    }

    return retiradas
}
fun retirarDeJogo(id: Int) {
    val novaLista = Array(personagens.size - 1) { arrayOf<String>() }
    var count = 0
    for (i in personagens.indices) {
        if (i != id) {
            novaLista[count] = personagens[i]
            count++
        }
    }
    personagens = novaLista
    for ( i in 1 until personagens.size) {
        personagens[i][0] = (i-1).toString() + personagens[i][0].substring(1)
    }
}

fun main() {
    var continuar = true
    var personagensLidos = false
    while (continuar) {
        if (!jogoAtivo) {
            println(obterMenu())
            val opcao : String? = readLine()
            when (opcao) {
                "1" -> {
                    if (!personagensLidos) {
                        println("Antes de iniciar o jogo tem de ler as personagens.")
                        println("(prima enter para voltar ao menu)")
                        readLine()
                    } else {
                        println("Bem vindo. Eu selecionei uma personagem. Tente adivinhar quem e fazendo perguntas sobre suas caracteristicas.")
                        jogoAtivo = true
                        indicePersonagemEscolhido = gerarPersonagem()
                        println(obterMenuJogo())
                    } }
                "2" -> {
                    personagensLidos = lerPersonagens()
                    println(MENSAGEM_PERSONAGENS_LIDOS_COM_SUCESSO)
                    println("(prima enter para voltar ao menu)")
                    readLine()
                }
                "0" -> {
                    continuar = false
                    println("Ate logo!")
                }
                else -> {
                    println("Opcao invalida, tente novamente.")
                } }
        } else {
            println("O que pretende fazer?")
            val opcaoJogo = readLine()
            when (opcaoJogo) {
                "perguntar" -> {
                    println("Identifique o atributo e a sua designacao, por exemplo, \"genero masculino\".")
                    val pergunta = readLine()
                    val personagensRetiradas = perguntar(pergunta ?: "", indicePersonagemEscolhido)
                    if (personagensRetiradas != -1) {
                        if (personagensRetiradas == 1) {
                            println("Foi retirada do jogo 1 personagem.")
                        } else {
                            println("Foram retiradas do jogo $personagensRetiradas personagens.")
                        }
                        val resultado = mostrarPersonagens()
                        if(resultado.isNotEmpty()) {
                            println(resultado)
                        } else {
                        }
                    } else {
                        println("Pergunta invalida.")
                        println(mostrarPersonagens())
                    } }
                "personagens" -> {
                    println(mostrarPersonagens())
                }
                "sair" -> {
                    jogoAtivo = false
                }
                else -> {
                    println("Opcao invalida.")
                    println(obterMenuJogo())
                } } } }
}